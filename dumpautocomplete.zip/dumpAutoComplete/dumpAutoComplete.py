#!/usr/bin/env python
#==========================================================================
#--------------------------------------------------------------------------
# Project : dumpAutoComplete - convert mork or SQLite files to XML
# File    : dumpAutoComplete.py
# Version : 0.7
#--------------------------------------------------------------------------
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# Version 2 (1991) as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# For the full text of the GNU General Public License, refer to:
#   http://www.fsf.org/licenses/gpl.txt
#
# For alternative licensing terms, please contact the author.
# Original "Mindy" copyright: Kumaran Santhanam <kumaran@alumni.stanford.org>
# Subsequent butchery: Mike Hoye <mhoye@off.net>
# Additional mutilation: Corey Benninger <corey.benninger@foundstone.com>
#
# Updates can be found at http://www.foundstone.com/resources/freetools.htm
#
#==========================================================================
VERSION = "0.7"

import sys
import re
import getopt
import time

from sys import stdin, stdout, stderr

#*************************************************************************#
# Print Usage if needed... in most cases you won't see this displayed     #
#*************************************************************************#

def usage ():
    print
    print "dumpAutoComplete %s - dump FireFox autocomplete data -> XML" % VERSION
    print
    print "Copyright 2006 (c) by Foundstone, a division of McAfee"
    print "by Corey Benninger. Based on a Mork/Mindy converter, (c) 2005 Kumaran Santhanam and Mike Hoye <mhoye@off.net>."
    print
    print
    print "usage: dumpAutoComplete [formhistory[.dat|.sqlite]]"
    print


#*************************************************************************#
# Classes for sorting Mork Data                                           #
#*************************************************************************#
class Database:
    def __init__ (self):
        self.cdict  = { }
        self.adict  = { }
        self.tables = { }

class Table:
    def __init__ (self):
        self.id     = None
        self.scope  = None
        self.kind   = None
        self.rows   = { }

class Row:
    def __init__ (self):
        self.id     = None
        self.scope  = None
        self.cells  = [ ]

class Cell:
    def __init__ (self):
        self.column = None
        self.atom   = None



#*************************************************************************#
# Mork File Processing                                                    #
#*************************************************************************#
def escapeData (match):
    return match.group() \
               .replace('\\\\n', '$0A') \
               .replace('\\)', '$29') \
               .replace('>', '$3E') \
               .replace('}', '$7D') \
               .replace(']', '$5D')

pCellText   = re.compile(r'\^(.+?)=(.*)')
pCellOid    = re.compile(r'\^(.+?)\^(.+)')
pCellEscape = re.compile(r'((?:\\[\$\0abtnvfr])|(?:\$..))')

backslash = { '\\\\' : '\\',
              '\\$'  : '$',
              '\\0'  : chr(0),
              '\\a'  : chr(7),
              '\\b'  : chr(8),
              '\\t'  : chr(9),
              '\\n'  : chr(10),
              '\\v'  : chr(11),
              '\\f'  : chr(12),
              '\\r'  : chr(13) }

def unescapeMork (match):    
    s = match.group()
    s.replace('t','-')
    if s[0] == '\\':
        return backslash[s]
    else:
        return '' ###chr(int(s[1:], 16)) ## Seems to be extraneous data

def decodeMorkValue (value):
    global pCellEscape
    return pCellEscape.sub(unescapeMork, value)

def addToDict (dict, cells):
    for cell in cells:
        eq  = cell.find('=')
        key = cell[1:eq]
        val = cell[eq+1:-1]
        dict[key] = decodeMorkValue(val)

def getRowIdScope (rowid, cdict):
    idx = rowid.find(':')
    if idx > 0:
        return (rowid[:idx], cdict[rowid[idx+2:]])
    else:
        return (rowid, None)
        
def delRow (db, table, rowid):
    (rowid, scope) = getRowIdScope(rowid, db.cdict)
    if scope:
        rowkey = rowid + "/" + scope
    else:
        rowkey = rowid + "/" + table.scope

    if table.rows.has_key(rowkey):
        del table.rows[rowkey]

def addRow (db, table, rowid, cells):
    global pCellText
    global pCellOid
    global gbDebug

    row = Row()
    (row.id, row.scope) = getRowIdScope(rowid, db.cdict)

    for cell in cells:
        obj = Cell()
        cell = cell[1:-1]

        match = pCellText.match(cell)
        if match:
            obj.column = db.cdict[match.group(1)]
            obj.atom   = decodeMorkValue(match.group(2))

        else:
            match = pCellOid.match(cell)
            if match:
                obj.column = db.cdict[match.group(1)]
                obj.atom   = db.adict[match.group(2)]

        if obj.column and obj.atom:
            row.cells.append(obj)

    if row.scope:
        rowkey = row.id + "/" + row.scope
    else:
        rowkey = row.id + "/" + table.scope

    if table.rows.has_key(rowkey) and gbDebug:
        print >>stderr, "ERROR: duplicate rowid/scope %s" % rowkey
        print >>stderr, cells

    table.rows[rowkey] = row
    
def inputMork (data):
    global gbDebug
    # Remove beginning comment
    pComment = re.compile('//.*')
    data = pComment.sub('', data, 1)

    # Remove line continuation backslashes
    pContinue = re.compile(r'(\\(?:\r|\n))')
    data = pContinue.sub('', data)

    # Remove line termination
    pLine = re.compile(r'(\n\s*)|(\r\s*)|(\r\n\s*)')
    data = pLine.sub('', data)

    # Create a database object
    db          = Database()

    # Compile the appropriate regular expressions
    pCell       = re.compile(r'(\(.+?\))')
    pSpace      = re.compile(r'\s+')
    pColumnDict = re.compile(r'<\s*<\(a=c\)>\s*(?:\/\/)?\s*(\(.+?\))\s*>')
    pAtomDict   = re.compile(r'<\s*(\(.+?\))\s*>')
    pTable      = re.compile(r'\{-?(\d+):\^(..)\s*\{\(k\^(..):c\)\(s=9u?\)\s*(.*?)\}\s*(.+?)\}')
    pRow        = re.compile(r'(-?)\s*\[(.+?)((\(.+?\)\s*)*)\]')

    pTranBegin  = re.compile(r'@\$\$\{.+?\{\@')
    pTranEnd    = re.compile(r'@\$\$\}.+?\}\@')

    # Escape all '%)>}]' characters within () cells
    data = pCell.sub(escapeData, data)

    # Iterate through the data
    index  = 0
    length = len(data)
    match  = None
    tran   = 0
    while 1:
        if match:  index += match.span()[1]
        if index >= length:  break
        sub = data[index:]

        # Skip whitespace
        match = pSpace.match(sub)
        if match:
            index += match.span()[1]
            continue

        # Parse a column dictionary
        match = pColumnDict.match(sub)
        if match:
            m = pCell.findall(match.group())
            # Remove extraneous '(f=iso-8859-1)'
            if len(m) >= 2 and m[1].find('(f=') == 0:
                m = m[1:]
            addToDict(db.cdict, m[1:])
            continue

        # Parse an atom dictionary
        match = pAtomDict.match(sub)
        if match:
            cells = pCell.findall(match.group())
            addToDict(db.adict, cells)
            continue

        # Parse a table
        match = pTable.match(sub)
        if match:
            id = match.group(1) + ':' + match.group(2)

            try:
                table = db.tables[id]

            except KeyError:
                table = Table()
                table.id    = match.group(1)
                table.scope = db.cdict[match.group(2)]
                table.kind  = db.cdict[match.group(3)]
                db.tables[id] = table

            rows = pRow.findall(match.group())
            for row in rows:
                cells = pCell.findall(row[2])
                rowid = row[1]
                if tran and rowid[0] == '-':
                    rowid = rowid[1:]
                    delRow(db, db.tables[id], rowid)

                if tran and row[0] == '-':
                    pass

                else:
                    addRow(db, db.tables[id], rowid, cells)
            continue

        # Transaction support
        match = pTranBegin.match(sub)
        if match:
            tran = 1
            continue

        match = pTranEnd.match(sub)
        if match:
            tran = 0
            continue

        match = pRow.match(sub)
        if match and tran:
            if gbDebug:
            	print >>stderr, "WARNING: using table '1:^80' for dangling row: %s" % match.group()
            rowid = match.group(2)
            if rowid[0] == '-':
                rowid = rowid[1:]

            cells = pCell.findall(match.group(3))
            delRow(db, db.tables['1:80'], rowid)
            if row[0] != '-':
                addRow(db, db.tables['1:80'], rowid, cells)
            continue

        # Syntax error
        if gbDebug:
        	print >>stderr, "ERROR: syntax error while parsing MORK file"
        	print >>stderr, "context[%d]: %s" % (index, sub[:40])
        index += 1

    # Return the database
    return db


#*************************************************************************#
# Hunt for autocomplete files if none are given                           #
#*************************************************************************#
gWebAppStoreFile = ''      # This will keep track if processing WebAppStore

def findFile ():
        import ConfigParser
        import os
        global gWebAppStoreFile

        cp = ConfigParser.ConfigParser()

        if os.name == 'posix':
        	#Unix Systems
                if os.path.isfile (os.environ['HOME'] + '/.mozilla/firefox/profiles.ini'):
                        cp.readfp (open(os.environ['HOME'] + '/.mozilla/firefox/profiles.ini' ))
                        filebase = os.environ['HOME'] + "/.mozilla/firefox/" + cp.get('Profile0','path') + '/'
		#MacOSX Systems
		elif os.path.isfile ('/Users/' + os.environ['USER'] + '/Library/Application Support/Firefox/profiles.ini'):
			cp.read('/Users/' + os.environ['USER'] + '/Library/Application Support/Firefox/profiles.ini')
			filebase ='/Users/' + os.environ['USER'] + '/Library/Application Support/Firefox/' + cp.get('Profile0','Path',True) + '/'
                else:
                        #Looks like Firefox is not installed
                        return ''
                        

        #Windows Systems
        if (os.name == 'nt') or (os.name == 'dos'):
                if os.path.isfile (os.environ['APPDATA'] + '\Mozilla\Firefox\Profiles.ini'):
                        cp.readfp (open(os.environ['APPDATA'] + '\Mozilla\Firefox\Profiles.ini' ))
                        filebase = os.environ['APPDATA'] + "\Mozilla\Firefox\\" + cp.get('Profile0','path').replace('/','\\') + "\\"
                else:
                        #Looks like Firefox is not installed, or non-Windows system
                        return ''

        # Test For SQLite AutoComplete File (FF2.0 + greater)
        if os.path.isfile ( filebase + 'formhistory.sqlite' ):
                # Since we're hunting for files, dump WebAppStore as well if it exsists
                if os.path.isfile ( filebase + 'webappsstore.sqlite' ):
                        gWebAppStoreFile = filebase + 'webappsstore.sqlite'
                return filebase + 'formhistory.sqlite'

        # Test For SQLite WebAppStore File (FF2.0 + greater)
        if os.path.isfile ( filebase + 'webappsstore.sqlite' ):
                return filebase + 'webappsstore.sqlite'

        # Test For Mork File (FF1.5 + less)
        if os.path.isfile ( filebase + 'formhistory.dat' ):
                return filebase + 'formhistory.dat'

        return ''


#*************************************************************************#
# This will format and sort the Mork data into an Array for the XML output#
#*************************************************************************#

def formatMork (db):
    mydb = []
    tables = db.tables.keys()    
    for table in [ db.tables[k] for k in tables ]:
       rows = table.rows.keys()
       for row in [ table.rows[k] for k in rows ]:
       	  #Make the array of rows [Field name, Saved data] 
       	  if len(row.cells) > 1:
          	mydb.append([row.cells[0].atom, row.cells[1].atom])
          
    mydb.sort()
    return mydb


#*************************************************************************#
# XML out                                                                 #
#*************************************************************************#
bXMLHeaderSet = False	      # Keep Track if we've written the XML Headers

def xmlEncoding (datastring):
    return datastring \
               .replace('&', '&amp;') \
               .replace('"', '&quot;') \
               .replace('>', '&gt;') \
               .replace('<', '&lt;') \
               .replace("'", '&apos;') 


def outputXML (db, filename):
    global bXMLHeaderSet
    global gWebAppStoreFile
    
    lastfield = ''
    print '<?xml version="1.0" standalone="yes"?>'
    print '<cachedata>'
    bXMLHeaderSet = True
    
    curtime = time.strftime('%a %b %d %Y %H:%M:%S', time.localtime(time.time()))  
    print '  <autocomplete file="%s" time="%s">' % (xmlEncoding(filename), curtime)

    for row in db:
        if row[0] != lastfield:
        	if lastfield != '':
        		print '    </field>'
        	print '    <field name="%s">' % (xmlEncoding(row[0]))
        	lastfield = row[0]
        	
        print '      <saved>%s</saved>' % (xmlEncoding(row[1]))
    
    if lastfield != '':			#Only print this if data was found
    	print '    </field>'
    print '  </autocomplete>'
    
    #Must Close CacheData tag if there's no WebAppStore data
    if gWebAppStoreFile == '':
    	print '</cachedata>'
    


def outputXMLWebAppStore (db, filename):
    global bXMLHeaderSet
    if not (bXMLHeaderSet):
    	print '<?xml version="1.0" standalone="yes"?>'
    	print '<cachedata>'
    	
    curtime = time.strftime('%a %b %d %Y %H:%M:%S', time.localtime(time.time()))    	
    print '  <webappstore file="%s" time="%s">' % (xmlEncoding(filename), curtime)

    for row in db:      		
	print '    <record domain="%s" key="%s" secure="%d">' % (xmlEncoding(row[0]),xmlEncoding(row[1]),row[2])
	print '      <saved>%s</saved>' % (xmlEncoding(row[3]))
	print '    </record>'
        	
    print '  </webappstore>'
    print '</cachedata>'
    
    
#*************************************************************************#
# See if this is WebAppStore data from FF2.0                              #
#*************************************************************************#

def processWebAppStore (filename):
    try:
      from pysqlite2 import dbapi2 as sqlite
      conweb = sqlite.connect(filename)
      curweb = conweb.cursor()
      curweb.execute("select distinct domain, key, secure, value from moz_webappsstore order by domain, key")            
      outputXMLWebAppStore(curweb, filename)
      curweb.close()
      conweb.close()
      return 0
    except conweb.DatabaseError:
      return 1
            

#*************************************************************************#
# The MAIN                                                                #
#*************************************************************************#
gbDebug = False

def main (argv=None):
    global gWebAppStoreFile
    global gbDebug
    if argv is None:  argv = sys.argv

    # Parse the command line arguments
    try:
        opts, args = getopt.getopt(argv[1:], "htv")
    except:
        print "Invalid command-line argument"
        usage()
        return 1

    # Process the switches
    for o, a in opts:
        if o in ("-h"):
            usage()
            return 0
        elif o in ("-v"):
            gdDebug = True

    # Read the filename
    if (len(args) != 1):
        filename = findFile()
        if (len(filename) == 0):
        	usage()
        	return 1
    else:
    	filename = args[0]

    # Read the file into memory
    try:
        if (filename != '-'):
            file = open(filename, "rtU")
        else:
            file = stdin
        data = file.read()
        file.close()        
    except:
	print "couldn't find file or read stdin: %s" % filename
	return 1

    # Determine the file type and process accordingly
    if (data.find('<mdb:mork') >= 0):
        db = inputMork(data)
        outputXML(formatMork(db), filename)
    else:
        try:
            from pysqlite2 import dbapi2 as sqlite
            con = sqlite.connect(filename)
            cur = con.cursor()
            cur.execute("select distinct fieldname, value from moz_formhistory order by fieldname")            
            outputXML(cur, filename)
            cur.close()
            con.close()
            if gWebAppStoreFile != '':
            	processWebAppStore(gWebAppStoreFile)
        	
	except con.DatabaseError:
	    #If not a WebAppStore File, Show an Error
	    if processWebAppStore(filename):
            	print "file format error: %s (Not MORK or SQLite?)" % filename
            	return 1

    # Return success
    return 0


if (__name__ == "__main__"):
    result = main()
    # Comment the next line to use the debugger
    sys.exit(result)
