Patchit 2.00
-------------

Patchit is a simple utility that can be used to patch binary files. It
does not offer differential patching but is instead designed to apply
simply byte changes to an existing file.


Version 2.00 does not represent any additional functionality to previous
versions of Patchit, it simply signifies the fact that Patchit has
been acquired by Foundstone (http://www.foundstone.com).


See the example files provided for information on how to use the PatchIt
scripting language.

----------------------------------------------------------------------
http://www.foundstone.com
robin.keir@foundstone.com
