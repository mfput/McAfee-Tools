FileWatch
---------

This is a program that monitors a given file for changes in size. It is very
efficient; a small program that uses almost no CPU time.

When the selected file is detected to have changed size or even just been written
to without changing it's size ICEWatch can play a given sound file and maximize
it's window showing the time and date of when the file changed.

o  Enter (or browse for) a filename in the "File to monitor" section.

o  If you want to detect when the file changes size, select the
   "Monitor file size changes" button, or if you simply want to know when
   the file has been written to without necessarily having it's size
   changed then select the "Monitor file writes" button.

o  Optionally select a sound file to play when the program detects a file change
   by entering (or browsing for) a WAV file in the "Audio" section. To test
   the sound you can press the "Play" button.

o  Optionally select a program to be executed when the program detects a
   file  change by entering (or browsing for) a file in the "Run" section.

o  To have the program minimize on pressing the Start button, select the
   "Minimize on Start" box.

o  To have the program totally hide itself (it won't appear on the task bar)
   when the program is minimized, select "Hide when minimized". To get the
   window to appear again simply run the program a 2nd time and it will
   reappear.

o  To have the program automatically pop up when a file change is detected
   select "Maximize when file changes". When a change occurs the ICEWatch
   window will reappear and the time and date of the change will show in the
   "Change Times" list.


If you want the program to start up automatically upon executing, add the
command-line parameter "start". For example, create a shortcut icon for
ICEWatch (in the Startup folder if you want ICEWatch to start every time
your computrer starts), right-click on it and select Properties. In the "Target"
box of the properties window add a space to end of the program path and then add
the word start. While you are here you could also assign a keyboard shortcut such
as CTRL ALT I to run ICEWatch whenever you press that key sequence. ICEWatch
remembers all of the settings and filenames by saving them in the file
"icewatch.ini" in the same directory as the executable.


FileWatch 2.00
--------------

Version 2.0 does not represent any major additional functionality to
previous versions of FileWatch (ICEWatch), it simply signifies the fact that
FileWatch has been acquired by Foundstone (http://www.foundstone.com).


----------------------------------------------------------------------

http://www.foundstone.com
robin.keir@foundstone.com
