ShoWin 2.00
-----------

Version 2.00 does not represent any additional functionality to previous
versions of ShoWin, it simply signifies the fact that ShoWin has
been acquired by Foundstone (http://www.foundstone.com).

----------------------------------------------------------------------

http://www.foundstone.com
robin.keir@foundstone.com
